<?php
// require_once '../includes/block_io.php';
require_once '../includes/APIException.php';
require_once '../includes/BlockKey.php';
require_once '../includes/Client.php';

$apiKey = "50c8-b21e-e1a2-a1dd";
$version = 2; // API version
$pin = "hassanjkhber123456789123";
// $block_io = new BlockIo($apiKey, $pin, $version);
$block_io = new \BlockIo\Client($apiKey, $pin, $version);

$sellername = $_GET["seller"];
$receiveusd = $_GET["receiveusd"];
$receivebtc = $_GET["receivebtc"];
$btcaddress = $_GET["btcaddress"];
$pending = $_GET["pending"];
//$removedfrombalance = $sales - $total;
 //// BitPay BTC Rate

/*
// $url='https://block.io/api/v2/prepare_transaction/?api_key=50c8-b21e-e1a2-a1dd&amounts=0.55&to_addresses=2Mt36CvC8qzrx6xhDnvoHFEbjrA8Mn9np9p';
$url='https://bitpay.com/api/rates';
$json=json_decode( file_get_contents( $url ) );
// $fee = $json->data->estimated_network_fee;
$dollar=$btc=0;

foreach( $json as $obj ){
    if( $obj->code=='USD' )$btc=$obj->rate;
}*/

$url_btc =    'https://blockchain.info/ticker';
$response_btc = file_get_contents($url_btc);
$object_btc = json_decode($response_btc);
$usdprice = $object_btc->{"USD"}->{"last"};
$rate['rate'] =  $object_btc->{"USD"}->{"last"};
$rate = $rate['rate'];
$btc = $rate;

///// End Bitpay Btc Rate
 //// Block.io Api Estimate fee
$ApiKey = "50c8-b21e-e1a2-a1dd";
$UrlApi = "https://block.io/api/v2/get_network_fee_estimate/?api_key=$ApiKey&amounts=$receivebtc&to_addresses=$btcaddress";
$ch = curl_init("$UrlApi");
curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
curl_setopt($ch, CURLOPT_POST, true); 
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0); 
curl_setopt($ch, CURLOPT_TIMEOUT, 15); //timeout in second
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$postResultFee = curl_exec($ch);
$outputFee = json_decode($postResultFee);
$EstimatedFee = substr($outputFee->data->estimated_network_fee , 0, 9);
///// End Api
$EstimatedFeeDivision = substr($btc * $EstimatedFee,0,4);
$EstimatedFeeDivisionUsd = $EstimatedFeeDivision / 2;
////
$DivUsdtoBtc = file_get_contents("https://blockchain.info/tobtc?currency=USD&value=$EstimatedFeeDivisionUsd");
$DivUsdtoBtcAB = substr($DivUsdtoBtc, 0, 9);
////
$receivebtcMinusFee = $receivebtc - $DivUsdtoBtcAB;
include "header.php";

echo '
<div class="alert alert-danger fade in radius-bordered alert-shadowed"><b>Send payment <span class="glyphicon glyphicon-send"></span></b></div>
  <div class="col-md-5">
 <hr>
<form method="post">
<tr>
<td width="30%">Seller name :</td>
<td width="70%"><input type="text" class="form-control" size="60px" name="username" value="'.$sellername.'" readonly/></td>
</tr>
<tr>
<td width="30%">Amount in USD $ :</td>
<td width="70%"><input type="text" class="form-control" size="60px" name="amount" value="'.$receiveusd.'" readonly/></td>
</tr>
<tr>
<td width="30%">Amount in BTC :<i class="fa fa-bitcoin"></i></td>
<td width="70%"><input type="text" class="form-control" size="60px" name="abtc" value="'.$receivebtcMinusFee.'" readonly/></td>
</tr>
<tr>
<td width="30%">BTC address :</td>
<td width="70%"><input type="text" class="form-control" size="60px" name="adbtc" value="'.$btcaddress.'" readonly/></td>
</tr><br>
<tr><td colspan="2"><center><input type="submit" class="btn btn-primary" value="Send '.$receivebtcMinusFee.' BTC"/></center></td></tr>
<input type="hidden" name="start" value="work" />
</form>
<hr>
Fee Estimated : <b>'.$EstimatedFee.' <span class="glyphicon glyphicon-bitcoin"></span></b><font color="red"> <b>=~</b></font> <b>'.substr($btc * $EstimatedFee, 0, 4).'$</b>
</center>';
	 
if(isset($_POST['start']) and $_POST['start'] == "work"){
// if($_SERVER["REQUEST_METHOD"] == "POST"){
 $queryz = mysqli_query($dbcon, "SELECT * from resseller where username='$sellername'")or die("mysql error");
	  $rzaw = mysqli_fetch_array($queryz);
	  if ($rzaw['withdrawal'] == "requested") {
    $user = mysqli_real_escape_string($dbcon, $_POST['username']);
    $amount = mysqli_real_escape_string($dbcon, $_POST['amount']);
    $abtc = mysqli_real_escape_string($dbcon, $_POST['abtc']);
	// $urlbtc = mysqli_real_escape_string($dbcon, $_POST['urlbtc']);
	$urlbtc = '';
    $adbtc = mysqli_real_escape_string($dbcon, $_POST['adbtc']);
 $date = date('Y/m/d h:i:s');
 
 //// Block.io Api
// $withdraw = $block_io->withdraw(array("amount" => "$receivebtcMinusFee", "to_address" => "$btcaddress"));
// $status = $withdraw->status;
$estNetworkFee = $block_io->get_network_fee_estimate(array('to_address' => $btcaddress, 'amount' => $receivebtc));
$prepare_transaction_response = $block_io->prepare_transaction(array('to_address' => $btcaddress, 'amount' => $receivebtc));
$create_and_sign_transaction_response = $block_io->create_and_sign_transaction($prepare_transaction_response);
$submit_transaction_response = $block_io->submit_transaction(array('transaction_data' => $create_and_sign_transaction_response));
$status = $submit_transaction_response->status;

if ($status == "success") {
// $tx_id = $withdraw->data->txid;
$tx_id = $submit_transaction_response->data->txid;
$urlbtc = "https://www.blockchain.com/btc/tx/$tx_id";
////
     $query = mysqli_query($dbcon, "
   INSERT INTO rpayment
   (username,amount,abtc,adbtc,method,date,url,urid,rate,fee)
   VALUES
   ('$sellername','$receiveusd','$receivebtc','$btcaddress','cashout','$date','$urlbtc','0','$btc','$EstimatedFee')
   ")or die("mysql error");
  $query2 = mysqli_query($dbcon, "UPDATE resseller SET withdrawal='done', soldb='$pending' where username='$sellername'")or die("mysql error");
echo "Payment sent <br>Proof : $urlbtc ";
	  } else {
		  $error = $withdraw->data->error_message;
		  echo "Error sending payment! <br><textarea class='form-control'>$error</textarea>";
} 
} else {
	echo "Already paid!";
} }
?>