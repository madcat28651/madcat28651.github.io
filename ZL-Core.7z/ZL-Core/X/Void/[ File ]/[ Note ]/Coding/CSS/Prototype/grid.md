```
    background-color: var(--main-bg-color) !important;
    background-image:
      repeating-linear-gradient(var(--main-color-dim) 0 1px, transparent 1px 100%),
      repeating-linear-gradient(90deg, var(--main-color-dim) 0 1px, transparent 1px 100%) !important;
    background-size: 4px 4px !important;
    border: 1px solid var(--main-border-color) !important;
    box-sizing: border-box !important;
```